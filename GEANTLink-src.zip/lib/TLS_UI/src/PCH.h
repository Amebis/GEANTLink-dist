/*
    SPDX-License-Identifier: GPL-3.0-or-later
    Copyright © 2015-2021 Amebis
    Copyright © 2016 GÉANT
*/

#pragma once

// Prevent warnings from wxWidgets headers
#define _CRT_SECURE_NO_WARNINGS

#include "../include/TLS_UI.h"

#include <wxex/valnet.h>

#include <WindowsX.h>
