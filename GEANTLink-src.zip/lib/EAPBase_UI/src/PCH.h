/*
    SPDX-License-Identifier: GPL-3.0-or-later
    Copyright © 2015-2022 Amebis
    Copyright © 2016 GÉANT
*/

#pragma once

#include "../include/EAP_UI.h"
#include "../include/Module.h"

#include <wxex/common.h>

#include <wx/app.h>
#include <wx/commandlinkbutton.h>
