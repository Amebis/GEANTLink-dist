/*
    SPDX-License-Identifier: GPL-3.0-or-later
    Copyright © 2020-2022 Amebis
    Copyright © 2016 GÉANT
*/

#pragma once

#include "../../../include/Version.h"

#include <Windows.h>
#include <evntprov.h>
#include <EventsETW.h>

#include <WinStd/Win.h>

#include <tchar.h>
