#EventMonitor
Output real-time G�ANTLink events to console

##Usage
```
EventMonitor
```

Press Ctrl+C to stop the program.
